function compute()
{
    var principal=document.getElementById("principal").value;
    var rate=document.getElementById("rate")
    var years=document.getElementById("years").value;
    var interest=principal*years*rate/100;
    var year=new Date().getFullYear()+parseInt(years);
    p = document.getElementById("principal").value;
    var output=document.getElementById("result");
    output.innerHTML=slider.value; //display the default slider value

    rate.oninput=function(){
        output.innerHTML=this.value;
    }
    
}
        